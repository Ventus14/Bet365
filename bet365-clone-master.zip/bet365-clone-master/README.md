#### [Built with CloudBet API](https://www.cloudbet.com/api/)

#### [See it live](https://bet365-clone.vercel.app/)

![Homepage Gif](https://github.com/RyanKendrick/bet365-clone/blob/master/public/imgs/get-odds-demo.gif?raw=true)

![Homepage Gif](https://github.com/RyanKendrick/bet365-clone/blob/master/public/imgs/responsive-demo.gif?raw=true)




