const SportsData = [
    {
        name: "Football",
        img: "./imgs/sports/football.svg"
    },
    {
        name: "Hockey",
        img: "./imgs/sports/hockey.svg"
    },
    {
        name: "Baseball",
        img: "./imgs/sports/baseball.svg"
    },
    {
        name: "Soccer",
        img: "./imgs/sports/soccer.svg"
    },
    {
        name: "Tennis",
        img: "./imgs/sports/tennis.svg"
    },
    {
        name: "Basketball",
        img: "./imgs/sports/basketball.svg"
    },
]
   



export default SportsData;