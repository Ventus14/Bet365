

function InPlay() {
    return (

    <div>Data:</div>

    )
}

export default InPlay